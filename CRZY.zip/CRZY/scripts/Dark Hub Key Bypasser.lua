--Dark Hub key system bypasser, because V3 key system is shit.
--Works on all games supported by DarkHub but universal won't work because I'm lazy and stupid.
SupportedGames=game:GetService('HttpService'):JSONDecode(game:HttpGet('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/SupportedGames')) --sets a variable in this case being the game list
for _,v in pairs(SupportedGames)do
    if game.PlaceId==tonumber(v)then --detects if the game is on the list and if it is then it loads the proper game
        loadstring(game:HttpGet('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/'.._))()
    end
end