-- Thank YOU for using DexHub. We can't thank you enough!

loadstring(game:HttpGet("https://raw.githubusercontent.com/HonestlyDex/DexHub/main/Init"))()